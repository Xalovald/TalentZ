import 'package:flutter/material.dart';
import 'package:talentz/assets/colors/colors.dart';

class UserView extends StatelessWidget {
  const UserView({super.key});
  
  @override
  Widget build(BuildContext context) {
    return Container(
      color: CustomColors.red(),
    );
  }
}