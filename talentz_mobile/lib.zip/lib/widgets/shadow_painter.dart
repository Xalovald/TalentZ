import 'package:flutter/material.dart';

abstract class ShadowPainter extends CustomPainter {
}